package com.example.android_projet;

import android.graphics.Bitmap;

public class Services {

    private String name;
    private String desc;
    private Bitmap img;
    private String geoloc;

    public Services(String name, String desc, Bitmap img, String geoloc){
        this.desc = desc;
        this.name = name;
        this.img = img;
        this.geoloc = geoloc;
    }

    public Bitmap getImg() {
        return img;
    }

    public String getDesc() {
        return desc;
    }

    public String getGeoloc() {
        return geoloc;
    }

    public String getName() {
        return name;
    }
}
