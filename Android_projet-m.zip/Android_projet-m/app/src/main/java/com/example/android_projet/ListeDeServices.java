package com.example.android_projet;

import android.content.Context;

import java.util.ArrayList;

public class ListeDeServices {

    public ArrayList<Services> liste;

    public ListeDeServices(Context context){

    }
}
